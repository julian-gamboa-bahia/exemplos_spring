package com.spring.exemplos.crud.dezembro082020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Dezembro082020ApplicationTests {

	@Test
	void contextLoads() {
	}

}

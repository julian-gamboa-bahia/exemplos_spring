package com.spring.exemplos.crud.dezembro082020;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Dezembro082020Application {

	public static void main(String[] args) {
		SpringApplication.run(Dezembro082020Application.class, args);
	}

}
